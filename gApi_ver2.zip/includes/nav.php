<?php
    /*$pocetna="";$nove="";
    switch ($active) {
        case 'pocetna': $pocetna='active'; break;
        case 'clanci': $nove='active'; break;
    }
    */
?>
    <fieldset>
        <label for="vreme">Prikazi vesti: </label>
        <select name="vreme" id="vreme" class="filter">
            <option value="1">OD DANAS</option>
            <option value="3">ZADNJIH 3 DANA</option>
            <option value="5">ZADNJIH 5 DANA</option>
            <option value="7">ZADNJIH 7 DANA</option>
        </select>
    </fieldset>
    <fieldset>
        <label for="kategorija">Izaberi kategoriju: </label>
        <select name="kategorija" id="kategorija" class="filter">
            <option value="0">Sve kategorije</option>
            <?php
            $db=new DB();
            $db->get("SELECT id_kategorije,naziv FROM kategorija");
            $rez=$db->res;
            foreach($rez as $r) {
            ?>
                <option value="<?php echo $r["id_kategorije"]; ?>"><?php echo $r["naziv"]; ?></option>
            <?php
            }
            ?>
        </select>
    </fieldset>
        <fieldset>
            <div class="fb-like" data-href="http://www.mvesti.rs" data-layout="standard" data-action="like" data-show-faces="true" data-share="true"></div>
        </fieldset>
