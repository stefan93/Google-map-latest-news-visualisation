
<?php
require ("core/init.php");
if (!isset($_SESSION["id_korisnika"])) {
    header("Location:index.php");
    die();
} else {
    $id_korisnika=$_SESSION["id_korisnika"];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <title>CMS</title>
    <?php require ("includes/header.php")?>
</head>
<body>
<?php
$active='pocetna';
require_once 'includes/nav.php';
?>
<div class="container">

</div>
</body>
</html>