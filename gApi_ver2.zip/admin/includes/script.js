$(document).ready(function(){
    jQuery(document).on("click","[triger=dodaj_vest]",function(event){
        event.preventDefault();
        var id=$(this).attr("id");
        var grad=$('select[name=grad-'+id+']').val();
        var kat=$('select[name=kategorija-'+id+']').val();
        $("#"+id+".kontrola").load("ajax.dodaj_vest.php?q="+id+"&kat="+kat+"&grad="+grad);
    });
    jQuery(document).on("click","[triger=obrisi_vest]",function(event){
        event.preventDefault();
        var id=$(this).attr("id");
        $("#"+id+".kontrola").load("ajax.obrisi_vest.php?q="+id);
        setTimeout(function() {
            location.reload();
        },1500);
    });
    jQuery(document).on("click","[triger=ucitaj_nove_vesti]",function(event){
        event.preventDefault();
        var n=$(this).attr("id");
        timer=setInterval(function () {
            $("[triger=ucitaj_nove_vesti]").toggle();
        }, 500);
        $("#nove-vesti").load("ajax.ucitaj_nove_vesti.php?XDEBUG_SESSION_START=4545&n="+n,function() {
            window.clearInterval(timer);
            setTimeout(function() {
                location.reload();
            },1500);
        });
    });
    jQuery(document).on("click","[triger=promeni_grad]",function(event){
        event.preventDefault();
        var id=$(this).attr("id");
        window.open("promeni_grad.php?q="+id,"_blank","width=1000, height=500, top=100, left=100");
    });
    jQuery(document).on("click","[triger=odobri_vest]",function(event){
        event.preventDefault();
        var id=$(this).attr("id");
        $("#"+id+".promena-kategorije").load("ajax.odobri_vest.php?q="+id);
        setTimeout(function() {
            location.reload();
        },1500);
    });
    jQuery(document).on("click","[triger=promeni_kategoriju]",function(event){
        event.preventDefault();
        var id=$(this).attr("id");
        var kat=$('select[name=kategorija-'+id+']').val();
        $("#"+id+".promena-kategorije").load("ajax.promeni_kategoriju.php?q="+id+"&kat="+kat);
        setTimeout(function() {
            location.reload();
        },1500);
    });
    jQuery(document).on("click","[triger=dodaj_novinu]",function(event){
        event.preventDefault();
        var naziv=$("[name=naziv_nove_novine]").val();
        var link=$("[name=link_nove_novine]").val();
        var tip="dodaj_novu_novinu";
        $(this).load("ajax.podesavanja.php?tip="+tip+"&naziv="+naziv+"&link="+link);
        setTimeout(function() {
            location.reload();
        },1500);
    });
    jQuery(document).on("click","[triger=dodaj_novinu]",function(event){
        event.preventDefault();
        var naziv=$("[name=naziv_nove_novine]").val();
        var link=$("[name=link_nove_novine]").val();
        var tip="dodaj_novu_novinu";
        $(this).load("ajax.podesavanja.php?tip="+tip+"&naziv="+naziv+"&link="+link);
        setTimeout(function() {
            location.reload();
        },1500);
    });
    jQuery(document).on("click","[triger=sacuvaj_novine_za_auto]",function(event){
        event.preventDefault();
        var novine=[];
        $(".novine-za-auto").each(function() {
            var s;
            if ($(this).is(":checked"))
                s=1;
            else
                s=0;
            novine.push(
                {
                    "id_novina": $(this).attr("value"),
                    "set": s
                });
        });
        novine=JSON.stringify(novine);
        var tip="sacuvaj_rss_za_auto";
        $(this).load("ajax.podesavanja.php?tip="+tip+"&novine="+novine);
        setTimeout(function() {
            location.reload();
        },1500);
    });
    jQuery(document).on("click","[triger=dodaj_rss_link]",function(event){
        event.preventDefault();
        var link=$("[name=novi_rss_link]").val();
        var novina=$("select[name=novina_za_rss_link]").val();
        var tip="dodaj_rss_link";
        $(this).load("ajax.podesavanja.php?tip="+tip+"&novina="+novina+"&link="+link);
        setTimeout(function() {
            location.reload();
        },1500);
    });
    jQuery(document).on("click","[triger=izbrisi_rss_link]",function(event){
        event.preventDefault();
        var id=$(this).attr("id");
        var tip="izbrisi_rss_link";
        $(this).load("ajax.podesavanja.php?tip="+tip+"&id="+id);
        setTimeout(function() {
            location.reload();
        },1500);
    });
    jQuery(document).on("click","[triger=promeni_aktivni_grad_grad]",function(event){
        event.preventDefault();
        var id_vesti=$(this).attr("id");
        var id_grada=$("select[name=grad-"+id_vesti+"]").val();
        $(this).load("ajax.promeni_akt_grad.php?&id_grada="+id_grada+"&id_vesti="+id_vesti);
        setTimeout(function() {
            location.reload();
        },1500);
    });


});