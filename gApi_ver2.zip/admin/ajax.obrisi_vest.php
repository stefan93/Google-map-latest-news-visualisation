<?php
/**
 * Created by PhpStorm.
 * User: Stefan
 * Date: 28.7.2015
 * Time: 20:10
 */
require("core/init.php");
if (!isset($_SESSION["id_korisnika"])) {
    header("Location:index.php");
    die();
}
if (isset($_GET['q'])) {
    $id=sanitize($_GET['q']);
    $v=new Vest($id);
        if ($v->obrisi() == 1)
            echo 'Vest je obrisana.';
        else
            echo 'Greska tokom brisanja vesti.';
    } else {
        echo 'Greska u GET';
    }
