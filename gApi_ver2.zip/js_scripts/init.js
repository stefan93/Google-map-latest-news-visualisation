/**
 * Created by Stefan on 12.6.2015.
 */
var styles=[
   {
        "featureType":"administrative.country","elementType":"geometry","stylers":
            [
                {"weight": 4}
            ]
    },{
        "featureType":"road","elementType":"geometry","stylers":
            [
                {"weight":"0.3"}
            ]
    },{
        "featureType":"road","elementType":"labels.icon","stylers":
            [
                {"visibility":"off"}
            ]
    }
];
var styledMap = new google.maps.StyledMapType(styles,
    {name: "Styled Map"});
//make map
var mapOptions = {
    zoom: 9,
    minZoom: 9,
    disableDefaultUI: true
};
var map = new google.maps.Map(document.getElementById('map-canvas'),
    mapOptions);
map.mapTypes.set('map_style', styledMap);
map.setMapTypeId('map_style');
//Geocoding: set center to Serbia
var country = "Serbia";
geocoder = new google.maps.Geocoder();
geocoder.geocode( {'address' : country}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
        map.setCenter(results[0].geometry.location);
    }

});
var oms = new OverlappingMarkerSpiderfier(map,
    {markersWontMove: true, markersWontHide: true, circleFootSeparation: 2000,spiralLengthStart: 2200, spiralFootSeparation: 1600, spiralLengthFactor: 2200});