<?php
/**
 * Created by PhpStorm.
 * User: Stefan
 * Date: 4.8.2015
 * Time: 1:23
 */
$GLOBALS["config"]=array(
    "db" => array("type" => "mysql",
        "username" => "root",
        "host" => "localhost",
        "password" => "",
        "database" => "gapi",
    ),
    "error_report" => "DEV" ,//LIVE or DEV
    "adresa" => "http://localhost/gapi/vesti-iz-srbije.php"
);

spl_autoload_register(function($class){
    require "../classes/class.".$class.".php";
});

require ("../functions/function.sanitize.php");
require ("../functions/function.my_error_handler.php");
require ("../functions/function.mb_isupper.php");

Aplikacija::auto_vesti();

?>